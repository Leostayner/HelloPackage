def world():
    print("Hello Word")